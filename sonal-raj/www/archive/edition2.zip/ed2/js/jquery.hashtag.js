if(window.location.hash) {
	var hash = window.location.hash.substring(1);
} else {
	
}